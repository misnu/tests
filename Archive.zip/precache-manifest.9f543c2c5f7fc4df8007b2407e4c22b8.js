self.__precacheManifest = [
  {
    "revision": "35692cde67b63dec3bf9",
    "url": "/static/css/main.fc79621a.chunk.css"
  },
  {
    "revision": "35692cde67b63dec3bf9",
    "url": "/static/js/main.f2644b07.chunk.js"
  },
  {
    "revision": "5ccf274a4261e83913b5",
    "url": "/static/js/runtime~main.c7e67974.js"
  },
  {
    "revision": "f2a2d6eb3e9b746e4ac6",
    "url": "/static/css/2.c7f78bce.chunk.css"
  },
  {
    "revision": "f2a2d6eb3e9b746e4ac6",
    "url": "/static/js/2.5b60be94.chunk.js"
  },
  {
    "revision": "a6fda3e3aeb023957dc2",
    "url": "/static/js/3.02be95fb.chunk.js"
  },
  {
    "revision": "3c23d99d3611bfb613153003b2e9076b",
    "url": "/static/media/asix-logo.3c23d99d.png"
  },
  {
    "revision": "e6ebbae39242d020e1707bf67df4cfed",
    "url": "/index.html"
  }
];